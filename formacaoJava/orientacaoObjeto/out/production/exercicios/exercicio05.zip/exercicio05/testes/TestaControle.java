package exercicio05.testes;

import exercicio05.classes.Caminhao;
import exercicio05.classes.Pluviometro;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TestaControle {
    public static void main(String[] args) {

        List<Caminhao> novoCaminhao = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        Boolean registraCaminhao = true;
        while (registraCaminhao) {
            System.out.println("Digite 1 - Alfa | 2 - Beta");
            int tipoCaminhao = sc.nextInt();
//            System.out.println("Digite capacidade");
//            int capacidadeCaminhao = sc.nextInt();
            Caminhao caminhao = new Caminhao(tipoCaminhao);
            Boolean registraPluviometro = true;
            while (registraPluviometro) {
                System.out.println("Digite 1 - Gama | 2 - Delta");
                int tipoPluviometro = sc.nextInt();
                Caminhao.setPluviometros(new Pluviometro(tipoPluviometro));
//                Pluviometro pluviometro = new Pluviometro(tipoPluviometro);

            }


        }


    }
}
