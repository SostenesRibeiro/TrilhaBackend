package exercicio05.classes;

import java.util.ArrayList;
import java.util.List;

public class Caminhao {
    private String tipoCaminhao;
    private List<Pluviometro> pluviometros = new ArrayList<>();
    private int capacidadeCaminhao;

    public Caminhao(int tipo) {
        this.setTipoCaminhao(tipo);
        // this.capacidadeCaminhao = capacidadeCaminhao;
    }

    public static void setPluviometros(Pluviometro pluviometro) {
        this.pluviometros = pluviometros;

    }

    public String getTipoCaminhao() {
        return tipoCaminhao;
    }

    public void setTipoCaminhao(int tipoCaminhao) {
        if (tipoCaminhao == 1) {
            this.tipoCaminhao = "Alfa";
            this.capacidadeCaminhao = 10;
        } else {
            this.tipoCaminhao = "Beta";
            this.capacidadeCaminhao = 15;
        }
    }

    public List<Pluviometro> getPluviometros() {
        return pluviometros;
    }

    public void setPluviometros(List<Pluviometro> pluviometros) {
        this.pluviometros = pluviometros;
    }

    public int getCapacidadeCaminhao() {
        return capacidadeCaminhao;
    }

    public void setCapacidadeCaminhao(int capacidadeCaminhao) {
        this.capacidadeCaminhao = capacidadeCaminhao;
    }
}
