package exercicio05.classes;

public class Pluviometro {
    private String tipoPluviometro;
    private Double capacidadePluviometro;

    public Pluviometro(int tipo) {
        this.setTipoPluviometro(tipo);
        this.setCapacidadePluviometro(tipo);
    }

    public String getTipoPluviometro() {
        return tipoPluviometro;
    }

    public void setTipoPluviometro(int tipoPluviometro) {
        if (tipoPluviometro == 1) {
            this.tipoPluviometro = "Gama";
        } else {
            this.tipoPluviometro = "Delta";
        }
    }

    public Double getCapacidadePluviometro() {
        return capacidadePluviometro;
    }

    public void setCapacidadePluviometro(int tipoPluviometro) {
        if (tipoPluviometro == 1) {
            this.capacidadePluviometro = 0.5;
        } else {
            this.capacidadePluviometro = 1.0;
        }
    }
}
