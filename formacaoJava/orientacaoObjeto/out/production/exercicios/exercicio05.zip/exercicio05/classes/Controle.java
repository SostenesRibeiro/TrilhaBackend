package exercicio05.classes;

public class Controle {
}
